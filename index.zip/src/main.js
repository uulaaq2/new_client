import { createApp } from 'vue'
import { createPinia } from 'pinia'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import * as bootstrap from '../node_modules/bootstrap/dist/js/bootstrap.bundle'
import './assets/css/main.css'
import axios from 'axios'
import App from './App.vue'
import router from './router'
import icons from './icons'
import { useUserStore } from './stores/user'
import VueCookies from 'vue-cookies'

const app = createApp(App)

// consts
app.config.globalProperties.$devMode = 'dev'
app.config.globalProperties.$siteUrl = app.config.globalProperties.$devMode === 'dev' ? 'http://localhost:5173/' : 'http://iibos.com.au/'
app.config.globalProperties.$apiUrl = app.config.globalProperties.$devMode === 'dev' ? 'http://localhost/api/' : 'http://iibos.com.au/api/'
app.config.globalProperties.$corporateName = 'Indorama Ventures Oxides Australia Pty Ltd'
app.config.globalProperties.$cookieExpiresIn = '14d'

// axios
app.config.globalProperties.$axios = axios.create({
    baseURL: app.config.globalProperties.$apiUrl,
    withCredentials: true
})

app.config.globalProperties.$goto = async (routeName) => {       
    router.push(router.resolve({name: routeName}).href)   
}
// goto

app.config.globalProperties.$getInput = (elementID) => {
    return document.getElementById(elementID)
}
// getInput

app.config.globalProperties.$getInputValue = (elementID) => {
    return document.getElementById(elementID).value
}
// getInputValue

app.config.globalProperties.$setInputValue = (elementID, value) => {
    document.getElementById(elementID).value = value
}
// setInputValue

app.config.globalProperties.$focus = (elementID) => {
    document.getElementById(elementID).focus()
}
// focus

app.config.globalProperties.$checkResponseForErrors = (response, metaData) => {
    let gotoError = false

    if (!response.data) {
        gotoError = true
    } else {
        if (!response.data.code_src) {
            gotoError = true
        }
    }

    if (gotoError) {
        if (app.config.globalProperties.$devMode === 'dev') {
            app.config.globalProperties.$global_error = response
            app.config.globalProperties.$goto('error')    
        } else {
            metaData['formError'] = 'An error occoured'
            return
        }
    } 

    if (response.data.code !== 'ok') {
        if (response.data.code !== 'shouldChangePassword') {
            metaData.formError = response.data.message ? response.data.message : response.data.code
            return false
        }
    }

    return true
}
// checkResponseForErrors

app.config.errorHandler = (error) => {
    app.config.globalProperties.$global_error = error
    app.config.globalProperties.$goto('error')
}
// error handler

app.config.globalProperties.$icons = icons
// icons

const publicPages = [
    'public',
    'signin',
    'change_password',
    'error'
]
// public pages

router.beforeEach(async (to, from) => {  
    const { user } = useUserStore()
    
    if (publicPages.includes(to.name)) {
      return 
    }  

    if (!user.full_name) {
      app.config.globalProperties.$signIn()
    }  
})
// router before

router.afterEach((to, from) => {
    document.title = `${to.meta.title}  | IBOS` 
    
    //app.config.globalProperties.$ibos_app.set_background_image(to.meta.mainPage ? 'main' : '')
 })
// router after

app.config.globalProperties.$signIn = async () => {
    try {
      const { set_user} = useUserStore()

      const response = await axios.post(app.config.globalProperties.$apiUrl + 'cp/user/signin.php');
        
      if (!response) {
        throw new Error('Network error, no respsonse')
      }
  
      if (response.data.code === 'shouldChangePassword') {
        set_user(response.data)
  
        app.config.globalProperties.$goto('public')
  
        return
      }
  
      if (response.data.code !== 'ok') {
        app.config.globalProperties.$goto('public')
        
        return
      }
  
      set_user(response.data.payload.user)
  
      return
    } catch (error) {
      app.config.globalProperties.$global_error = error
      app.config.globalProperties.$goto('error')
    }
  }
  // signin

 app.config.globalProperties.$set_background = async (type) => {
    if (type === 'main') {
        const response = await axiosInstance.post('/get_app_setting.php', {
            setting_name: 'background_image'
          })
          
          if (response.data.code !== 'ok') {
            throw new Error(response.data)          
          }
  
          document.body.style.backgroundImage = `url("${app.config.globalProperties.$ibos_app.backgrounds_url + response.data.payload.value}")`
          document.body.style.backgroundPosition = 'center'
          document.body.style.backgroundSize = 'cover'
    } else {
        document.body.style.backgroundImage = ''
        document.body.style.backgroundColor = 'white'
    }
}
 // set background image
 
 app.config.globalProperties.$checkPasswordStrength = (password) => {
    let regex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    return regex.test(password);
 }
 // checkPasswordStrength

app.config.globalProperties.$validate = (metaData) => {
    if (!metaData) return false      

    for (var prop in metaData) {
        if (!metaData.hasOwnProperty(prop) || !metaData[prop]['type']) {
            continue;
        }      

        metaData[prop]['error'] = ''
    }

    metaData['formError'] = ''
    metaData['erroredInputs'] = []     

    for (var prop in metaData) {
        if (!metaData.hasOwnProperty(prop)) {
            continue;
        }      

        if (metaData[prop]['type'] !== 'checkbox' && metaData[prop]['type'] !== 'radio') {
            
            if (metaData[prop]['required']) {
                if (document.getElementById(metaData[prop]['id']).value.replace(/\s/g,'').length === 0) {                   
                    metaData[prop]['error'] = metaData[prop]['label'] + ' is required'
                    metaData['erroredInputs'].push(metaData[prop]['id'])
                } else {
                    metaData[prop]['value'] = document.getElementById(metaData[prop]['id']).value
                }
            }     

            if (metaData[prop]['regex']) {
               if (!app.config.globalProperties.$checkPasswordStrength(metaData[prop]['value'])) {
                    metaData[prop]['error'] = metaData[prop]['regexError']
                    metaData['erroredInputs'].push(metaData[prop]['id'])
               }
            }

            if (metaData[prop]['matchTo']) {
                if (metaData[prop]['value'] !== metaData[metaData[prop]['matchTo']]['value']) {
                    metaData[prop]['error'] = metaData[prop]['label'] + ' does not match to ' + metaData[metaData[prop]['matchTo']]['label']
                    metaData['erroredInputs'].push(metaData[prop]['id'])
                }
            }
        }

        if (metaData[prop]['type'] === 'checkbox') {                
            if (metaData[prop]['required']) {                    
                if (!document.getElementById(metaData[prop]['id']).checked) {
                    metaData[prop]['error'] = metaData[prop]['label'] + ' is required'
                    metaData['erroredInputs'].push(metaData[prop]['id'])
                } 
            } else {
                metaData[prop]['value'] = document.getElementById(metaData[prop]['id']).checked
            }
        }
    }

    if (metaData['erroredInputs'].length > 0) {            
        document.getElementById(metaData['erroredInputs'][0]).focus()

        return false
    }           

    return true
}
 // validate

app.use(createPinia())
app.use(router)
app.use(VueCookies, { expires: '7d'})

app.mount('#app')
