<template>
    <div class="container-fluid pt-5">
        <div class="row">
            <div class="col d-flex justify-content-center">
                <img src="@/assets/images/logo_color.png" :alt="$corporateName" width="100" class="mb-5"/>
            </div>
        </div>

        <div class="row justify-content-sm-center">
            <div class="col-sm-10 col-md-8 col-lg-5">
                <div class="card w-100">
                    <div class="card-body">
                        <form @submit.prevent="signin">
                            <base-input :metaData="metaData.email_address" class="mb-3" />
                            <base-input :metaData="metaData.password" class="mb-4" />
                            <base-checkbox :metaData="metaData.remember_me" class="mb-4" />
                            
                            <form-error v-if="metaData.formError" :formError="metaData.formError" class="mb-3" />

                            <base-button type="submit" class="btn btn-primary w-100" :loading="loading">Sign in</base-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <change-password :on-close="updatePasswordField" :show-current-password="true" />
</template>

<script>
    import {v4 as uuidv4 } from 'uuid'
    import BaseInput from '../components/base/BaseInput.vue'
    import BaseCheckbox from '../components/base/BaseCheckbox.vue'
    import BaseButton from '../components/base/BaseButton.vue'
    import FormError from '../components/base/FormError.vue'
    import { useUserStore } from '../stores/user'
    import ChangePassword from '../views/ChangePassword.vue'

    export default {
        setup() {
            const { set_user } = useUserStore()

            return {
                set_user
            }
        },
        components: {
            BaseInput,
            BaseCheckbox,
            BaseButton,
            FormError,
            ChangePassword
        },
        data() {
            return {       
                shouldChangePassword: false,
                shouldVerifyAccount: false,
                metaData: {
                    email_address: {
                        id: uuidv4(),
                        label: 'Email address or account number',
                        type: 'text',
                        required: true
                    },
                    password: {
                        id: uuidv4(),
                        label: 'Password',
                        type: 'password',
                        required: true
                    },
                    remember_me: {
                        id: uuidv4(),
                        label: 'Keep me signed in',
                        type: 'checkbox',
                        required: false
                    }
                },
                loading: false
            }
        },
        methods: {            
            async signin() {
                if (!this.$validate(this.metaData)) return

                this.loading = true

                let formData = new FormData()
                formData.append('username', this.metaData.email_address.value)
                formData.append('password', this.metaData.password.value)
                formData.append('remember_me', this.metaData.remember_me.value)
               
                const response = await this.$axios.post(this.$apiUrl + 'cp/user/signin.php', formData)
                console.log(response);
                
                if (!this.$checkResponseForErrors(response, this.metaData)) {
                    this.loading = false
                    return
                }

                this.set_user(response.data)

                const isAccountValid = [
                    'invalidCredentials',
                    'accountIsNotActive',
                    'accountIsExpired'
                ]

                if (isAccountValid.includes(response.data.code)) {
                    this.metaData.formError = response.data.message
                    this.loading = false
                    return
                }

                if (response.data.code === 'shouldChangePassword') {
                    this.loading = false
                    this.showChangePassword()
                    return
                }

                await this.$goto('home')                
            },

            updatePasswordField(password) {
                this.metaData.password.value = password
                this.$setElementValue(this.metaData.password.id, password)                
            },

            showChangePassword() {
                const CPModal = new bootstrap.Modal(document.getElementById('CPModal'))
                CPModal.show()
            }
        },
        mounted() {
            document.body.style.backgroundImage = '';

            if (!this.$cookies.get('email_address')) {
                document.getElementById(this.metaData.email_address.id).focus()
            } else {
                document.getElementById(this.metaData.password.id).focus()
            }
        }
    }
</script>