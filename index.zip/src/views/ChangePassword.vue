<template>
    <div class="modal fade" id="CPModal" tabindex="-1" aria-labelledby="CPModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change your password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="CPForm">
                    <base-input v-if="showCurrentPassword" :metaData="metaData.currentPassword" class="mb-3" />
                    <base-input :metaData="metaData.password" class="mb-3" />
                    <base-input :metaData="metaData.passwordAgain" class="mb-3" />

                    <form-error v-if="metaData.formError" :formError="metaData.formError" class="mb-3" />
                </form>

            </div>
            <div class="modal-footer">
                <base-button 
                    class="btn btn-primary w-100" 
                    :loading="loading"
                    @click="changePassword"
                >
                    Change password
                </base-button>
            </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {v4 as uuidv4 } from 'uuid'
    import BaseInput from '../components/base/BaseInput.vue'
    import BaseButton from '../components/base/BaseButton.vue'
    import { storeToRefs } from 'pinia'
    import { useUserStore } from '../stores/user'
    import FormError from '../components/base/FormError.vue'

    export default {
        setup() {
            const { user } = storeToRefs(useUserStore())

            return {
                user
            }
        },
        props: {
            showCurrentPassword: {
                type: Boolean,
                default: false
            },
            onClose: {
                type: Function,
                default: null
            }
        },

        components: {
            BaseInput,
            BaseButton,
            FormError
        },

        data() {
            return {
                loading: false,
                metaData: {
                    currentPassword: {
                        id: uuidv4(),
                        label: 'Current password',
                        type: 'password',
                        required: this.showCurrentPassword
                    },
                    password: {
                        id: uuidv4(),
                        label: 'New password',
                        type: 'password',
                        regex: '/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$',
                        regexError: 'Password should be minimun 8 Characters, with at least a symbol, upper and lower case letters and a number',
                        required: true
                    },
                    passwordAgain: {
                        id: uuidv4(),
                        label: 'New password again',
                        type: 'password',
                        required: true,
                        matchTo: 'password'
                    }
                }
            }
        },
        methods: {
            async changePassword() {
                if (this.showCurrentPassword) {
                    const currentPassword = this.$getInputValue(this.metaData.currentPassword.id)
                    
                    this.metaData.currentPassword.value = currentPassword

                    if (!this.metaData.currentPassword.value) {
                        this.metaData.currentPassword.error = this.metaData.currentPassword.label + ' is required'
                        this.$getInput(this.metaData.currentPassword.id).focus()
                        return
                    }

                    const canContiune = await this.isCurrentPasswordValid()                    

                    if (!canContiune) {
                        return
                    }                         
                }                  

                this.loading = true

                if (!this.$validate(this.metaData)) return

                if (this.onClose) {
                    this.onClose(this.metaData.password.value)
                }
            },

            async isCurrentPasswordValid() {
                const formData = new FormData()
                formData.append('account_number', this.user.account_number)
                formData.append('password', this.metaData.currentPassword.value)

                const response = await this.$axios.post("cp/user/check_password.php", formData)

                if (!this.$checkResponseForErrors(response, this.metaData)) {
                    this.loading = false
                    return
                }

            },
        },
        mounted() {
        },
    }
</script>