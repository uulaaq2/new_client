<template>
  home
</template>

<script>
  import { useUserStore } from '../stores/user'
  
  export default {
    setup() {
      const { user } = useUserStore()

      return {
        user
      }
    }
  }
</script>

