<template>
    <div class="container">
        <div class="row">
            <div class="col mt-5">
                <p>Data: {{ $global_error.data ? $global_error.data : $global_error }}</p>
            </div>
        </div>
    </div> 
</template>

<script>
    export default {
        
    }
</script>