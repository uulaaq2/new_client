<template>
    <div class="container-fluid bg-light d-flex justify-content-between align-items-center px-2 py-1">
        <img src="@/assets/images/logo_color.png" :alt="$corporateName" width="60" />
        <button class="btn btn-warning" @click="$goto('signin')">Sign in</button>
    </div>
</template>

<script>
    export default {
        mounted() {
            document.body.style.backgroundImage = `url('/public_background.jpg')`
            document.body.style.backgroundPosition = 'center'
            document.body.style.backgroundSize = 'cover'
        }
    }
</script>

<style>
    
</style>