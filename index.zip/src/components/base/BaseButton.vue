<template>
    <button
        v-bind="$attrs"
        :class="{'position-relative': true}"
        :style="{'pointer-events': loading ? 'none' : 'auto'}"
        :loading="loading"        
    >
        <div v-if="showSpinner" class="buttonSpinner">
            <Icon :icon="$icons.buttonSpinner" />
        </div>

        <slot />
    </button>
</template>

<script>
    import { Icon } from '@iconify/vue'

    export default {
        props: {
            loading: {
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                showSpinner: false
            }
        },

        components: {
            Icon
        },

        watch: {
            loading(newValue) {
                if (newValue) {
                    setTimeout(() => {
                        this.showSpinner = this.loading
                    }, 800);
                } else {
                    this.showSpinner = false
                }
            }
        }
    }
</script>