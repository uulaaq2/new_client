<template>
    <div class="d-flex align-items-start text-danger fw-bold">        
        <Icon :icon="$icons.formError" class="me-2 mt-1" /> {{ formError }}
    </div>
</template>

<script>
    import { Icon } from '@iconify/vue'

    export default {
        props: {
            formError: {
                type: String,
                default: ''
            }
        },
        components: {
            Icon
        }
    }
</script>