<template>
   <div class="form-check">
    <input 
        class="form-check-input" 
        type="checkbox" 
        :checked="metaData.checked ? metaData.checked : false"
        :id="metaData.id"
        @input="$emit('update:modelValue', $event.target.checked)"
        v-bind="$attrs"
    >
    <label 
        class="form-check-label" 
        :for="metaData.id"
    >
        {{ metaData.label }}
    </label>

    <Transition>
        <div v-if="metaData.error" class="invalid-feedback show-feedback">
            {{ metaData.error }}
        </div>
    </Transition>
   </div>
</template>

<script>
    export default {
        props: {
          metaData: {
            type: Object,
            default: {}
          }
        }
    }
</script>

<style scoped>
    .show-feedback {
        font-size: .9rem;
    }

    .v-enter-active,
    .v-leave-active {
    transition: opacity 0.5s ease;
    }

    .v-enter-from,
    .v-leave-to {
    opacity: 0;
    }
</style>