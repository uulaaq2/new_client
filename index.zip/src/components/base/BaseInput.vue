<template>
    <div>
        <label v-if="metaData.label" :for="metaData.id" class="form-label mb-2">
            {{ metaData.label }}
        </label>
        <input 
            :id="metaData.id"
            :type="metaData.type"
            :placeholder="metaData.placeholder"
            class="form-control input" 
            autocomplete="new-password"
            @input="$emit('Update:modelValue', $event.target.value)"
            v-bind="$props"
            :required="metaData.inputRequired"
        />

        <Transition>
            <div v-if="metaData.error" class="invalid-feedback" :class="{'d-block': metaData.error}">
                {{ metaData.error }}
            </div>
        </Transition>

        <Transition>
            <div v-if="metaData.info" class="valid-feedback text-secondary" :class="{'d-block': metaData.info}">
                {{ metaData.info }}
            </div>
        </Transition>

        <Transition>
            <div v-if="metaData.success" class="valid-feedback" :class="{'d-block': metaData.success}">
                {{ metaData.success }}
            </div>
        </Transition>
    </div>
</template>

<script>
    export default {
        props: {
            metaData: {
                type: Object,
                default: {}
            }
        }
    }
</script>

<style scoped>
    .input:focus {
        background: #54ffd0;
    }    
    .v-enter-active,
    .v-leave-active {
    transition: opacity 0.5s ease;
    }

    .v-enter-from,
    .v-leave-to {
    opacity: 0;
    }
</style>