<script>
  import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

