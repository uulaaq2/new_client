import { defineStore } from "pinia"

export const useUserStore = defineStore('user', {
    state: () => ({ 
        user: {}
    }),
    getters: {
        get_user: (state) => state.user
    },
    actions: {
        set_user(user) {
            this.user = user            
        },
    }
})