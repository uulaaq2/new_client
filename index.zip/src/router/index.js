import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Public from '../views/Public.vue'
import Error from '../views/Error.vue'
import Signin from '../views/Signin.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      meta: {
        title: 'Welcome'
      },
      component: Home
    },
    {
      path: '/public',
      name: 'public',
      meta: {
        title: 'Public'
      },
      component: Public
    },
    {
      path: '/error',
      name: 'error',
      meta: {
        title: 'Error'
      },
      component: Error
    },
    {
      path: '/signin',
      name: 'signin',
      meta: {
        title: 'Sign in'
      },
      component: Signin
    }
  ]
})

export default router
