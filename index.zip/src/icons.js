export default {
    buttonSpinner: "eos-icons:loading",
    formError: "material-symbols:error-outline-rounded"
}